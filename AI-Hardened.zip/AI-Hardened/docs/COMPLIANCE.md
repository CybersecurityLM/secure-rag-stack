# Compliance — AI-Hardened
## LGPD · ISO/IEC 27001 · SOC 2 Type II

**SELOCK · selock.net**

---

## Conformidade com a LGPD (Lei 13.709/2018)

### Art. 46 — Medidas de Segurança

> *"Os agentes de tratamento devem adotar medidas de segurança, técnicas e administrativas aptas a proteger os dados pessoais de acessos não autorizados e de situações acidentais ou ilícitas de destruição, perda, alteração, comunicação ou qualquer forma de tratamento inadequado ou ilícito."*

**Como o AI-Hardened atende:**

| Requisito | Implementação |
|-----------|---------------|
| Controle de acesso | JWT local + rate limiting |
| Criptografia em repouso | LUKS AES-256-XTS |
| Registro de operações | Audit log JSONL imutável |
| Minimização de dados | Apenas chunks relevantes processados |
| Anonimização de logs | Logs com hash de usuário, não PII |

### Art. 49 — Sistemas Projetados com Boas Práticas

O AI-Hardened implementa **Privacy by Design** (Art. 49, §2º):
- Dados jamais saem do perímetro controlado
- Zero integração com processadores externos (OpenAI, Azure, Google)
- Auditoria técnica verificável por terceiros

### Transferência Internacional de Dados (Arts. 33-36)

**Resultado:** ✅ **NÃO APLICÁVEL**

O sistema não realiza transferência de dados para servidores externos, eliminando completamente os riscos do Capítulo V da LGPD.

---

## ISO/IEC 27001:2022 — Mapeamento de Controles

| Controle ISO 27001 | Cláusula | Implementação |
|--------------------|---------|---------------|
| Política de segurança da informação | A.5 | `docs/SECURITY.md` |
| Controle de acesso | A.8.2 | JWT + RBAC (roadmap) |
| Criptografia | A.8.24 | LUKS AES-256-XTS |
| Segurança em redes | A.8.20 | iptables DROP + Docker internal |
| Registro de atividades | A.8.15 | Audit log JSONL |
| Gestão de vulnerabilidades | A.8.8 | `scripts/verify_isolation.sh` |
| Segurança no desenvolvimento | A.8.25 | Repositório privado + revisão |

---

## SOC 2 Type II — Critérios de Serviço de Confiança

### CC6 — Controles de Acesso Lógico e Físico

- **CC6.1:** Medidas de segurança implementadas (LUKS, iptables, JWT)
- **CC6.6:** Transmissão protegida — **N/A**: sem transmissão externa
- **CC6.7:** Restrição de movimentação de dados — **✅ Zero egress**

### CC7 — Operações do Sistema

- **CC7.2:** Monitoramento de anomalias — Audit log com alertas configuráveis
- **CC7.3:** Avaliação de vulnerabilidades — `verify_isolation.sh` executável

### A1 — Disponibilidade

- Sistema documentado para operação local sem dependências de SLA externo
- Backup do vault recomendado via `scripts/backup_vault.sh` (roadmap)

---

## Setores com Requisitos Específicos

### ⚖️ Setor Jurídico

- **Sigilo profissional (OAB):** Dados de clientes jamais saem do escritório
- **Segredo de justiça:** Processamento local sem registro em servidores de terceiros
- **LGPD + Marco Civil:** Conformidade completa com dados de partes processuais

### 🏦 Setor Bancário

- **Resolução CMN 4.893/2021:** Política de segurança cibernética do Bacen
- **PCI-DSS (se aplicável):** Dados de cartão nunca processados por terceiros
- **Sigilo bancário (LC 105/2001):** Infraestrutura soberana

### 🏛️ Setor Governamental

- **Lei de Acesso à Informação (LAI):** Rastreabilidade completa via audit log
- **Decreto 9.994/2019 (ABIN):** Suporte a atividades de inteligência isoladas
- **PNSI — Política Nacional de Segurança da Informação:** Soberania tecnológica

---

## Declaração de Conformidade

> Este sistema foi projetado pela **SELOCK** para operar em conformidade com a legislação brasileira de proteção de dados e padrões internacionais de segurança da informação.
>
> A ausência de transmissão de dados para infraestruturas externas representa o controle de privacidade mais robusto disponível: **dados que nunca saem nunca são vazados**.

Para auditorias formais, relatórios de due diligence ou certificações, entre em contato:
**contato@selock.net** · **selock.net**
