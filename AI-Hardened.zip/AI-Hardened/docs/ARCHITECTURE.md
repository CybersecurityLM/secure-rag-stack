# Arquitetura — AI-Hardened
## Sistema RAG Private com Isolamento Total

**SELOCK · selock.net**

---

## Visão Geral

O AI-Hardened é uma stack de IA Generativa projetada para operar em **modo air-gap** — sem nenhuma conexão com servidores externos. Cada componente é escolhido e configurado para garantir que dados sensíveis jamais saiam do perímetro controlado.

---

## Diagrama de Componentes

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        SERVIDOR LOCAL (air-gap)                          │
│                                                                           │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                    REDE DOCKER INTERNA                             │  │
│  │                    172.28.0.0/16 (internal: true)                 │  │
│  │                                                                    │  │
│  │  ┌─────────────┐   ┌──────────────────┐   ┌──────────────────┐  │  │
│  │  │   NGINX UI  │   │   FastAPI + RAG  │   │  Ollama Engine   │  │  │
│  │  │  port 3000  │──▶│   port 8080      │──▶│  port 11434      │  │  │
│  │  │  (somente   │   │                  │   │                  │  │  │
│  │  │  localhost) │   │  • /api/query    │   │  Modelos locais: │  │  │
│  │  └─────────────┘   │  • /audit/       │   │  • llama3:8b     │  │  │
│  │                    │  • /collections  │   │  • phi3:mini     │  │  │
│  │                    │  • /health       │   │  • mistral:7b    │  │  │
│  │                    └────────┬─────────┘   └──────────────────┘  │  │
│  │                             │                                     │  │
│  │                    ┌────────▼─────────┐                          │  │
│  │                    │    ChromaDB      │                          │  │
│  │                    │    port 8000     │                          │  │
│  │                    │                  │                          │  │
│  │                    │  Banco vetorial  │                          │  │
│  │                    │  persistente     │                          │  │
│  │                    └────────┬─────────┘                          │  │
│  └─────────────────────────────┼──────────────────────────────────┘  │
│                                 │                                        │
│                    ┌────────────▼────────────────┐                     │
│                    │      VOLUME LUKS             │                     │
│                    │  /mnt/ai_vault               │                     │
│                    │                              │                     │
│                    │  ├── chromadb/    (vetores)  │                     │
│                    │  ├── docs/        (fontes)   │                     │
│                    │  ├── audit_logs/  (auditoria)│                     │
│                    │  └── models_cache/           │                     │
│                    │                              │                     │
│                    │  AES-256-XTS + Argon2id      │                     │
│                    │  SHA-512 hash do header      │                     │
│                    └──────────────────────────────┘                     │
│                                                                           │
│  iptables: OUTPUT POLICY DROP  ──────────────────────────────────────▶ │
│  (somente loopback e rede Docker interna permitidos)                VOID │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Fluxo de uma Query RAG

```
Usuário digita pergunta
        │
        ▼
[1] FastAPI recebe POST /api/query
        │
        ▼
[2] JWT verificado (local, sem chamada externa)
        │
        ▼
[3] Audit log: evento QUERY_START registrado
        │
        ▼
[4] Ollama gera embedding da pergunta
    (modelo: nomic-embed-text, 100% local)
        │
        ▼
[5] ChromaDB busca os N chunks mais similares
    (busca cosine no volume LUKS)
        │
        ▼
[6] Contexto montado com fontes numeradas
    (ex: [FONTE 1 — contrato.pdf, trecho 3])
        │
        ▼
[7] Prompt construído com contexto + pergunta
    + system prompt especializado por domínio
        │
        ▼
[8] Ollama LLM gera resposta
    (llama3:8b ou modelo configurado, 100% local)
        │
        ▼
[9] Resposta retornada com:
    • texto da resposta
    • fontes usadas com relevância
    • tempo de processamento
    • egress_bytes: 0 (sempre)
        │
        ▼
[10] Audit log: evento QUERY_COMPLETED registrado
        │
        ▼
Usuário recebe resposta
```

---

## Camadas de Segurança

### Camada 1 — Rede (Firewall)
- `iptables -P OUTPUT DROP` — nenhum pacote sai por padrão
- Somente loopback (`lo`) e rede Docker interna liberados
- Docker Compose com `internal: true` — containers sem rota para internet

### Camada 2 — Dados em Repouso (LUKS)
- Volume LUKS2 com AES-256-XTS (padrão NIST SP 800-38E)
- Key Derivation com Argon2id (resistente a GPU brute-force)
- Auto-seal em shutdown/suspend via systemd
- Keyfile de 512 bytes via `/dev/urandom`

### Camada 3 — Aplicação
- Ollama vinculado a `127.0.0.1:11434` — não acessível pela rede
- ChromaDB vinculado a `127.0.0.1:8000`
- FastAPI com CORS restrito a localhost
- Rate limiting por IP para prevenção de DoS

### Camada 4 — Auditoria
- Log JSONL com hashes encadeados (cada entrada referencia o hash da anterior)
- Adulteração retroativa detectável matematicamente
- IPs de usuários armazenados apenas como SHA-256 (anonimização)
- Campos `egress_bytes: 0` em cada entrada como prova de não-transmissão

---

## Decisões de Design

### Por que Ollama?
- Único runtime que permite rodar Llama/Mistral/Phi localmente sem dependências de nuvem
- Suporte a GPU (CUDA/ROCm) e CPU
- API compatível com OpenAI — facilita migração de código existente
- Binário único, fácil auditoria

### Por que ChromaDB?
- Banco vetorial embarcável — não requer servidor externo
- Persistência em diretório local (dentro do vault LUKS)
- `anonymized_telemetry=False` — zero telemetria
- Interface Python simples e auditável

### Por que LUKS2 + AES-256-XTS?
- Padrão da indústria para Full Disk Encryption em Linux
- XTS mode é adequado para storage (sem padding oracle)
- LUKS2 suporta Argon2id (melhor que PBKDF2 contra hardware especializado)
- Amplamente auditado e suportado pelo kernel Linux

### Por que hashes encadeados no audit log?
- Inspirado em estruturas de blockchain — cada entrada depende da anterior
- Adulteração de qualquer entrada invalida todas as subsequentes
- Verificável por qualquer auditor com acesso ao log
- Não requer banco de dados — arquivo JSONL simples e portátil

---

*SELOCK · Salvador, Bahia · selock.net*
