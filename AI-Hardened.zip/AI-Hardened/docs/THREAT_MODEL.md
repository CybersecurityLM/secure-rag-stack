# Modelo de Ameaças — AI-Hardened
## Análise STRIDE + Controles de Mitigação

**Versão:** 1.0  
**Data:** 2026-04-12  
**Autor:** SELOCK · selock.net  
**Classificação:** Público (repositório de demonstração)

---

## 1. Superfície de Ataque

```
ATORES EXTERNOS
     │
     │  (bloqueados por iptables + Docker internal network)
     ▼
╔════════════════════════════════════════════╗
║           PERÍMETRO DO SISTEMA             ║
║                                            ║
║  Browser → API (localhost:8080)            ║
║         → UI  (localhost:3000)             ║
║                                            ║
║  API → Ollama  (172.28.x.x:11434)          ║
║     → ChromaDB (172.28.x.x:8000)          ║
║     → /mnt/ai_vault (LUKS)                ║
║                                            ║
╚════════════════════════════════════════════╝
     │
     │  (isolado do mundo externo)
     ▼
   NULL (0 bytes de egress)
```

---

## 2. Análise STRIDE

### S — Spoofing (Falsificação de Identidade)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Usuário não autenticado acessa API | Requisição direta | JWT local + rate limiting | ✅ Mitigado |
| Container comprometido se passa por API | Rede Docker interna | mTLS entre serviços | 🔄 Roadmap |

### T — Tampering (Adulteração)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Adulteração de documentos no vault | Acesso físico ao disco | LUKS AES-256-XTS | ✅ Mitigado |
| Adulteração de embeddings no ChromaDB | Acesso ao container | Vault LUKS + checksums | ✅ Mitigado |
| Adulteração de modelos Ollama | Substituição de arquivo | SHA-256 verificado no pull | ✅ Mitigado |
| Injeção de prompt malicioso | Input da API | Sanitização + max tokens | ✅ Mitigado |

### R — Repudiation (Repúdio)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Usuário nega ter feito consulta | Sem logs | Audit log JSONL imutável | ✅ Mitigado |
| Adulteração retroativa de logs | Edição de arquivo | Hash encadeado (futuro: append-only) | 🔄 Roadmap |

### I — Information Disclosure (Divulgação de Informação)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Dados enviados para OpenAI/Azure | Modelo SaaS | Ollama 100% local | ✅ Mitigado |
| Embeddings exfiltrados via rede | Conexão externa | iptables DROP outbound | ✅ Mitigado |
| Dados em repouso legíveis | Acesso físico ao disco | LUKS AES-256-XTS | ✅ Mitigado |
| Logs contendo PII | Arquivo de log | Logs com hash de usuário (não IP) | ✅ Mitigado |
| Memory dump com dados sensíveis | Cold boot attack | Vault desmontado quando inativo | ✅ Mitigado |
| Dados em /tmp ou swap | Sistema operacional | Swap criptografado + tmpfs | ⚠️ Manual |

### D — Denial of Service (Negação de Serviço)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Flood de queries exaure GPU | Sem rate limit | Rate limiting na API | ✅ Mitigado |
| Documento gigante exaure RAM | Upload sem limite | Limite de tamanho no ingest | ✅ Mitigado |
| Vault cheio bloqueia operação | Espaço em disco | Alertas de capacidade | 🔄 Roadmap |

### E — Elevation of Privilege (Escalada de Privilégio)

| Ameaça | Vetor | Mitigação | Status |
|--------|-------|-----------|--------|
| Container escapa para host | Docker escape | Containers sem `--privileged` | ✅ Mitigado |
| API acessa vault diretamente | Path traversal | Validação de path + sandbox | ✅ Mitigado |
| Ollama executa código arbitrário | Model jailbreak | Sem exec tools no modelo | ✅ Mitigado |

---

## 3. Cenários de Ataque Prioritários

### Cenário 1: Insider Malicioso
**Descrição:** Funcionário com acesso ao servidor tenta exfiltrar documentos sensíveis.

**Controles:**
1. LUKS requer keyfile físico para montar vault
2. Logs de acesso com hash de usuário (rastreável)
3. Alertas para queries fora do horário comercial (roadmap)
4. Vault auto-lock após inatividade configurável

### Cenário 2: Comprometimento do Servidor
**Descrição:** Atacante obtém shell no servidor via CVE.

**Controles:**
1. Vault LUKS somente montado durante operação
2. Keyfile em hardware separado (YubiKey recomendado)
3. iptables DROP bloqueia exfiltração via rede
4. Dados em memória não persistidos fora do vault

### Cenário 3: Supply Chain Attack
**Descrição:** Imagem Docker ou modelo Ollama adulterado.

**Controles:**
1. Hashes SHA-256 de todos os modelos documentados em `configs/model_hashes.sha256`
2. Imagens Docker fixadas por digest (`image@sha256:...`)
3. Build offline após primeiro pull verificado
4. Verificação automática no startup

---

## 4. Controles Não Implementados (Roadmap)

| Controle | Prioridade | Justificativa |
|----------|-----------|---------------|
| mTLS entre serviços internos | Alta | Defesa em profundidade |
| Audit log com hash encadeado | Alta | Resistência a adulteração |
| YubiKey para vault unlock | Média | Alta segurança operacional |
| SELinux/AppArmor profiles | Média | Contenção de exploits |
| TPM 2.0 para keyfile | Baixa | Hardware específico necessário |

---

## 5. Declaração de Residual Risk

Com os controles implementados, o risco residual é:

- **Confidencialidade:** BAIXO — Dados criptografados em repouso e em memória isolada
- **Integridade:** BAIXO — LUKS + checksums de documentos
- **Disponibilidade:** MÉDIO — Single point of failure no servidor local (sem HA)

> Para ambientes de alta disponibilidade, consultar a SELOCK para arquitetura de cluster air-gapped.

---

*SELOCK · Salvador, Bahia · selock.net*
