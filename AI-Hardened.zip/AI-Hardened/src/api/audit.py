"""
AI-Hardened — Audit Log Engine
Log imutável com hashes encadeados (estilo blockchain simples)
Cada entrada contém o hash da entrada anterior — adulteração é detectável.
SELOCK · selock.net
"""

import json
import hashlib
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class AuditLog:
    """
    Log de auditoria com integridade verificável.

    Estrutura de cada entrada:
    {
      "seq":        int,          # Número sequencial
      "timestamp":  ISO-8601,
      "event":      str,
      "prev_hash":  str,          # Hash da entrada anterior (encadeamento)
      "entry_hash": str,          # Hash desta entrada
      "egress_bytes": 0,          # Sempre zero
      ...dados do evento
    }
    """

    def __init__(self, log_path: Path):
        self.log_path = log_path
        self._lock    = threading.Lock()
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

        # Carregar último hash para encadeamento
        self._last_hash = self._get_last_hash()
        self._seq       = self._get_last_seq()

    def _get_last_hash(self) -> str:
        """Retorna hash da última entrada ou hash genesis."""
        genesis = "0" * 64
        if not self.log_path.exists():
            return genesis
        try:
            lines = self.log_path.read_text().strip().splitlines()
            if not lines:
                return genesis
            last = json.loads(lines[-1])
            return last.get("entry_hash", genesis)
        except Exception:
            return genesis

    def _get_last_seq(self) -> int:
        if not self.log_path.exists():
            return 0
        try:
            lines = self.log_path.read_text().strip().splitlines()
            if not lines:
                return 0
            last = json.loads(lines[-1])
            return last.get("seq", 0)
        except Exception:
            return 0

    def _compute_hash(self, entry: dict) -> str:
        """SHA-256 do conteúdo da entrada."""
        canonical = json.dumps(entry, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(canonical.encode()).hexdigest()

    def record(self, event: str, data: dict, user_ip: Optional[str] = None) -> dict:
        """
        Registra evento de auditoria com encadeamento de hash.
        Thread-safe.
        """
        with self._lock:
            self._seq += 1

            # Anonimizar IP do usuário
            user_hash = None
            if user_ip:
                user_hash = hashlib.sha256(user_ip.encode()).hexdigest()[:16]

            entry = {
                "seq":          self._seq,
                "timestamp":    datetime.now(timezone.utc).isoformat(),
                "event":        event,
                "prev_hash":    self._last_hash,
                "egress_bytes": 0,
                **({} if user_hash is None else {"user_hash": user_hash}),
                **data,
            }

            # Calcular hash desta entrada
            entry["entry_hash"] = self._compute_hash(entry)
            self._last_hash = entry["entry_hash"]

            # Escrever de forma append-only
            with open(self.log_path, "a") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

            return entry

    def verify_integrity(self) -> dict:
        """
        Verifica a integridade de toda a cadeia de hashes.
        Detecta qualquer adulteração retroativa.
        """
        if not self.log_path.exists():
            return {"valid": True, "entries": 0, "message": "Log vazio"}

        lines = self.log_path.read_text().strip().splitlines()
        if not lines:
            return {"valid": True, "entries": 0, "message": "Log vazio"}

        errors      = []
        prev_hash   = "0" * 64
        last_seq    = 0

        for i, line in enumerate(lines):
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                errors.append(f"Linha {i+1}: JSON inválido")
                continue

            # Verificar encadeamento
            if entry.get("prev_hash") != prev_hash:
                errors.append(
                    f"Seq {entry.get('seq', '?')}: prev_hash não corresponde — "
                    f"possível adulteração na entrada {i+1}"
                )

            # Recalcular hash
            stored_hash = entry.pop("entry_hash", None)
            recomputed  = self._compute_hash(entry)
            entry["entry_hash"] = stored_hash  # restaurar

            if stored_hash != recomputed:
                errors.append(
                    f"Seq {entry.get('seq', '?')}: hash adulterado na entrada {i+1}"
                )

            # Verificar sequência
            seq = entry.get("seq", 0)
            if seq != last_seq + 1:
                errors.append(f"Seq {seq}: entrada fora de ordem (esperado {last_seq+1})")

            prev_hash = stored_hash or recomputed
            last_seq  = seq

        return {
            "valid":   len(errors) == 0,
            "entries": len(lines),
            "errors":  errors,
            "message": "Cadeia íntegra" if not errors else f"{len(errors)} problema(s) detectado(s)",
        }

    def tail(self, n: int = 50) -> list[dict]:
        """Retorna as últimas N entradas."""
        if not self.log_path.exists():
            return []
        lines = self.log_path.read_text().strip().splitlines()
        return [json.loads(l) for l in lines[-n:] if l.strip()]

    def search(self, event_type: Optional[str] = None, user_hash: Optional[str] = None) -> list[dict]:
        """Filtra entradas por tipo de evento ou usuário."""
        if not self.log_path.exists():
            return []

        results = []
        for line in self.log_path.read_text().splitlines():
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
                if event_type and entry.get("event") != event_type:
                    continue
                if user_hash and entry.get("user_hash") != user_hash:
                    continue
                results.append(entry)
            except Exception:
                continue
        return results


# Singleton global
_audit_instance: Optional[AuditLog] = None

def get_audit_log() -> AuditLog:
    global _audit_instance
    if _audit_instance is None:
        log_path = Path(os.getenv("AUDIT_LOG_PATH",
            "/mnt/ai_vault/audit_logs/api_audit.jsonl"))
        _audit_instance = AuditLog(log_path)
    return _audit_instance


import os
