"""
AI-Hardened — Autenticação JWT Local
Tokens gerados e validados offline — zero dependência externa
SELOCK · selock.net
"""

import os
import hmac
import json
import base64
import hashlib
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

JWT_SECRET       = os.getenv("JWT_SECRET", secrets.token_hex(32))
JWT_EXPIRE_HOURS = int(os.getenv("JWT_EXPIRE_HOURS", "8"))
JWT_ALGORITHM    = "HS256"

security = HTTPBearer(auto_error=False)


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _b64url_decode(s: str) -> bytes:
    padding = 4 - len(s) % 4
    return base64.urlsafe_b64decode(s + "=" * padding)


def create_token(user_id: str, role: str = "analyst") -> str:
    """Gera JWT HS256 localmente."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub":  user_id,
        "role": role,
        "iat":  int(now.timestamp()),
        "exp":  int((now + timedelta(hours=JWT_EXPIRE_HOURS)).timestamp()),
        "jti":  secrets.token_hex(8),
    }

    header  = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body    = _b64url_encode(json.dumps(payload).encode())
    signing = f"{header}.{body}".encode()
    sig     = hmac.new(JWT_SECRET.encode(), signing, hashlib.sha256).digest()

    return f"{header}.{body}.{_b64url_encode(sig)}"


def verify_token(token: str) -> dict:
    """Valida JWT e retorna payload ou lança HTTPException."""
    try:
        header_b64, body_b64, sig_b64 = token.split(".")
    except ValueError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token malformado")

    # Verificar assinatura
    signing  = f"{header_b64}.{body_b64}".encode()
    expected = hmac.new(JWT_SECRET.encode(), signing, hashlib.sha256).digest()
    provided = _b64url_decode(sig_b64)

    if not hmac.compare_digest(expected, provided):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Assinatura inválida")

    # Verificar expiração
    payload = json.loads(_b64url_decode(body_b64))
    if payload.get("exp", 0) < int(datetime.now(timezone.utc).timestamp()):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expirado")

    return payload


async def require_auth(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security)
) -> dict:
    """Dependency FastAPI — exige token válido."""
    # Em modo desenvolvimento (localhost sem token) — permitir com aviso
    if credentials is None:
        if os.getenv("ALLOW_NO_AUTH", "false").lower() == "true":
            return {"sub": "anonymous", "role": "analyst"}
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token de autenticação necessário",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return verify_token(credentials.credentials)


def require_role(required_role: str):
    """Dependency factory para controle de acesso por papel."""
    async def _check(payload: dict = Security(require_auth)):
        roles_hierarchy = {"admin": 3, "analyst": 2, "viewer": 1}
        user_level    = roles_hierarchy.get(payload.get("role", "viewer"), 0)
        required_level = roles_hierarchy.get(required_role, 999)
        if user_level < required_level:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Papel '{required_role}' necessário"
            )
        return payload
    return _check
