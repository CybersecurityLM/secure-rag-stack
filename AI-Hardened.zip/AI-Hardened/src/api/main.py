"""
AI-Hardened — FastAPI Server
RAG API 100% local com auditoria imutável
SELOCK · selock.net
"""

import os
import json
import hashlib
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import chromadb
from chromadb.config import Settings
from langchain_community.embeddings import OllamaEmbeddings
import httpx

# ── Config ───────────────────────────────────────────────────
VAULT_PATH = Path(os.getenv("VAULT_PATH", "/mnt/ai_vault"))
CHROMA_PATH = VAULT_PATH / "chromadb"
AUDIT_LOG   = VAULT_PATH / "audit_logs" / "api_audit.jsonl"
OLLAMA_URL  = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
LLM_MODEL   = os.getenv("LLM_MODEL", "llama3:8b")
TOP_K       = int(os.getenv("RAG_TOP_K", "5"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("ai-hardened.api")

# ── FastAPI App ──────────────────────────────────────────────
app = FastAPI(
    title="AI-Hardened Private RAG",
    description="IA Generativa 100% offline — Zero egress garantido",
    version="1.0.0",
    docs_url="/docs",   # Disponível apenas em localhost
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://127.0.0.1"],  # SOMENTE local
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ── Inicialização lazy ───────────────────────────────────────
_chroma_client = None
_embeddings    = None

def get_chroma():
    global _chroma_client
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(
            path=str(CHROMA_PATH),
            settings=Settings(anonymized_telemetry=False)
        )
    return _chroma_client

def get_embeddings():
    global _embeddings
    if _embeddings is None:
        _embeddings = OllamaEmbeddings(base_url=OLLAMA_URL, model=EMBED_MODEL)
    return _embeddings


# ── Auditoria ────────────────────────────────────────────────
def audit(event: str, request: Request, data: dict):
    user_ip   = request.client.host if request.client else "unknown"
    user_hash = hashlib.sha256(user_ip.encode()).hexdigest()[:16]

    record = {
        "timestamp":    datetime.now(timezone.utc).isoformat(),
        "event":        event,
        "user_hash":    user_hash,
        "egress_bytes": 0,
        **data
    }

    AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_LOG, "a") as f:
        f.write(json.dumps(record) + "\n")


# ── Schemas ──────────────────────────────────────────────────
class QueryRequest(BaseModel):
    question: str
    collection: str
    top_k: Optional[int] = TOP_K
    model: Optional[str] = LLM_MODEL


class QueryResponse(BaseModel):
    answer: str
    sources: list[dict]
    model: str
    collection: str
    egress_bytes: int = 0


# ── Endpoints ────────────────────────────────────────────────
@app.get("/health")
async def health():
    """Status do sistema e confirmação de isolamento."""
    vault_mounted = VAULT_PATH.exists()
    chroma_ready  = CHROMA_PATH.exists()

    return {
        "status":        "healthy" if vault_mounted else "degraded",
        "vault_mounted": vault_mounted,
        "chroma_ready":  chroma_ready,
        "ollama_url":    OLLAMA_URL,
        "model":         LLM_MODEL,
        "network_mode":  "air-gap",
        "egress_policy": "DROP",
        "timestamp":     datetime.now(timezone.utc).isoformat(),
    }


@app.get("/collections")
async def list_collections(request: Request):
    """Lista coleções disponíveis no vault."""
    try:
        client = get_chroma()
        cols   = [c.name for c in client.list_collections()]
        audit("LIST_COLLECTIONS", request, {"count": len(cols)})
        return {"collections": cols}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/query", response_model=QueryResponse)
async def query(req: QueryRequest, request: Request):
    """
    RAG Query — Busca semântica + geração de resposta local.

    1. Embed da query via Ollama (local)
    2. Busca vetorial no ChromaDB (local)
    3. Contexto injetado no prompt
    4. Geração via Ollama LLM (local)
    5. Retorno sem nenhum dado sair da máquina
    """
    if not req.question.strip():
        raise HTTPException(status_code=400, detail="Pergunta vazia")

    query_hash = hashlib.sha256(req.question.encode()).hexdigest()[:16]
    log.info(f"Query [{query_hash}] coleção={req.collection}")

    try:
        # 1. Embed da query
        embeddings = get_embeddings()
        query_vector = embeddings.embed_query(req.question)

        # 2. Busca no ChromaDB
        client     = get_chroma()
        collection = client.get_or_create_collection(req.collection)
        results    = collection.query(
            query_embeddings=[query_vector],
            n_results=min(req.top_k, 10),
            include=["documents", "metadatas", "distances"]
        )

        docs      = results["documents"][0]
        metadatas = results["metadatas"][0]
        distances = results["distances"][0]

        if not docs:
            return QueryResponse(
                answer="Nenhum documento relevante encontrado na coleção.",
                sources=[],
                model=req.model,
                collection=req.collection,
            )

        # 3. Montar contexto RAG
        context_parts = []
        for i, (doc, meta) in enumerate(zip(docs, metadatas)):
            source = meta.get("source_file", "desconhecido")
            context_parts.append(f"[Fonte {i+1}: {source}]\n{doc}")

        context = "\n\n---\n\n".join(context_parts)

        system_prompt = """Você é um assistente especializado que responde com base EXCLUSIVAMENTE 
nos documentos fornecidos no contexto. 

REGRAS CRÍTICAS:
- Responda APENAS com informações presentes no contexto
- Se a informação não estiver no contexto, diga explicitamente que não encontrou
- Cite a fonte (número e nome do arquivo) ao usar informações
- Seja preciso e objetivo
- Nunca invente ou extrapole informações não presentes nos documentos"""

        user_prompt = f"""Contexto dos documentos:

{context}

---

Pergunta: {req.question}

Responda com base nos documentos acima, citando as fontes relevantes."""

        # 4. Gerar resposta via Ollama (local)
        async with httpx.AsyncClient(timeout=120.0) as client_http:
            response = await client_http.post(
                f"{OLLAMA_URL}/api/chat",
                json={
                    "model": req.model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user",   "content": user_prompt},
                    ],
                    "stream": False,
                    "options": {"temperature": 0.1}  # Baixa temperatura para precisão
                }
            )
            response.raise_for_status()
            answer = response.json()["message"]["content"]

        # 5. Formatar fontes
        sources = [
            {
                "file":       m.get("source_file", "?"),
                "hash":       m.get("source_hash", "?")[:8],
                "relevance":  round(1 - d, 4),
                "chunk":      m.get("chunk_index", 0),
            }
            for m, d in zip(metadatas, distances)
        ]

        audit("QUERY_EXECUTED", request, {
            "query_hash":   query_hash,
            "collection":   req.collection,
            "model":        req.model,
            "sources_used": len(sources),
            "answer_len":   len(answer),
        })

        return QueryResponse(
            answer=answer,
            sources=sources,
            model=req.model,
            collection=req.collection,
        )

    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail=f"Ollama não disponível em {OLLAMA_URL}. Verifique: ollama serve"
        )
    except Exception as e:
        log.error(f"Erro na query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/audit/recent")
async def recent_audit(limit: int = 20):
    """Últimos eventos de auditoria."""
    if not AUDIT_LOG.exists():
        return {"events": []}
    with open(AUDIT_LOG) as f:
        lines = f.readlines()
    events = [json.loads(l) for l in lines[-limit:] if l.strip()]
    return {"events": events, "total": len(lines)}
