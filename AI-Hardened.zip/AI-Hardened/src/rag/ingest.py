"""
AI-Hardened — Document Ingestion Engine
Embeddings 100% locais via Ollama (nomic-embed-text)
SELOCK · selock.net
"""

import os
import sys
import json
import hashlib
import logging
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

import chromadb
from chromadb.config import Settings
from langchain_community.document_loaders import (
    PyPDFLoader, TextLoader, Docx2txtLoader, UnstructuredMarkdownLoader
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings

# ── Configuração de logging ──────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("/mnt/ai_vault/audit_logs/ingest.log", mode="a")
    ]
)
log = logging.getLogger("ai-hardened.ingest")

# ── Constantes ───────────────────────────────────────────────
VAULT_PATH = Path(os.getenv("VAULT_PATH", "/mnt/ai_vault"))
CHROMA_PATH = VAULT_PATH / "chromadb"
AUDIT_LOG = VAULT_PATH / "audit_logs" / "ingest_audit.jsonl"
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")

CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1000"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))

SUPPORTED_EXTENSIONS = {
    ".pdf":  PyPDFLoader,
    ".txt":  TextLoader,
    ".docx": Docx2txtLoader,
    ".md":   UnstructuredMarkdownLoader,
}


def verify_isolation() -> bool:
    """Verifica que o Ollama NÃO tem acesso externo."""
    import socket
    try:
        # Tentativa de resolver host externo deve falhar
        socket.getaddrinfo("api.openai.com", 443, timeout=2)
        log.warning("⚠ DNS externo resolvido — verificar isolamento de rede!")
        return False
    except (socket.gaierror, OSError):
        log.info("✓ Isolamento de rede confirmado")
        return True


def hash_file(filepath: Path) -> str:
    """SHA-256 do arquivo para rastreabilidade."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def audit_event(event_type: str, data: dict):
    """Registra evento de auditoria imutável em JSONL."""
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": event_type,
        "egress_bytes": 0,  # Sempre zero — sistema offline
        **data
    }
    with open(AUDIT_LOG, "a") as f:
        f.write(json.dumps(record) + "\n")


def load_document(filepath: Path):
    """Carrega documento baseado na extensão."""
    ext = filepath.suffix.lower()
    loader_class = SUPPORTED_EXTENSIONS.get(ext)

    if not loader_class:
        log.warning(f"Extensão não suportada: {ext} — ignorando {filepath.name}")
        return []

    try:
        loader = loader_class(str(filepath))
        docs = loader.load()
        log.info(f"Carregado: {filepath.name} ({len(docs)} páginas/seções)")
        return docs
    except Exception as e:
        log.error(f"Erro ao carregar {filepath.name}: {e}")
        return []


def ingest_documents(
    docs_path: Path,
    collection_name: str,
    overwrite: bool = False
) -> dict:
    """
    Pipeline principal de ingestão.

    1. Verifica isolamento de rede
    2. Carrega documentos do vault LUKS
    3. Chunking com sobreposição configurável
    4. Embeddings via Ollama (nomic-embed-text) — 100% local
    5. Persiste no ChromaDB dentro do vault
    6. Registra auditoria
    """

    log.info("═" * 60)
    log.info("AI-Hardened — Iniciando Ingestão")
    log.info(f"Coleção: {collection_name}")
    log.info(f"Fonte: {docs_path}")
    log.info("═" * 60)

    # 1. Verificar isolamento
    if not verify_isolation():
        log.error("ABORTANDO: Isolamento de rede comprometido")
        sys.exit(1)

    # 2. Verificar vault montado
    if not VAULT_PATH.exists():
        log.error(f"Vault não montado em {VAULT_PATH}")
        log.error("Execute: ./scripts/mount_vault.sh")
        sys.exit(1)

    if not docs_path.exists():
        log.error(f"Diretório de documentos não encontrado: {docs_path}")
        sys.exit(1)

    # 3. Inicializar ChromaDB (dentro do vault)
    log.info(f"Inicializando ChromaDB em {CHROMA_PATH}")
    client = chromadb.PersistentClient(
        path=str(CHROMA_PATH),
        settings=Settings(anonymized_telemetry=False)  # Zero telemetria
    )

    if overwrite and collection_name in [c.name for c in client.list_collections()]:
        client.delete_collection(collection_name)
        log.info(f"Coleção '{collection_name}' removida para reprocessamento")

    # 4. Embeddings locais via Ollama
    log.info(f"Inicializando embeddings: {EMBED_MODEL} @ {OLLAMA_BASE_URL}")
    embeddings = OllamaEmbeddings(
        base_url=OLLAMA_BASE_URL,
        model=EMBED_MODEL
    )

    # 5. Text splitter
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ".", "!", "?", ",", " "]
    )

    # 6. Processar documentos
    stats = {"files": 0, "chunks": 0, "errors": 0, "files_processed": []}
    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"}
    )

    doc_files = [
        f for f in docs_path.rglob("*")
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    log.info(f"Encontrados {len(doc_files)} documentos para processar")

    for filepath in doc_files:
        try:
            file_hash = hash_file(filepath)
            raw_docs = load_document(filepath)

            if not raw_docs:
                stats["errors"] += 1
                continue

            chunks = splitter.split_documents(raw_docs)
            log.info(f"  → {filepath.name}: {len(chunks)} chunks")

            # Gerar embeddings e inserir no ChromaDB
            texts = [c.page_content for c in chunks]
            metadatas = [
                {
                    **c.metadata,
                    "source_file": filepath.name,
                    "source_hash": file_hash,
                    "collection": collection_name,
                    "ingested_at": datetime.now(timezone.utc).isoformat(),
                    "chunk_index": i,
                }
                for i, c in enumerate(chunks)
            ]
            ids = [f"{file_hash[:8]}_{i}" for i in range(len(chunks))]

            # Embeddings locais — NENHUMA chamada externa
            vectors = embeddings.embed_documents(texts)

            collection.upsert(
                ids=ids,
                embeddings=vectors,
                documents=texts,
                metadatas=metadatas
            )

            stats["files"] += 1
            stats["chunks"] += len(chunks)
            stats["files_processed"].append({
                "name": filepath.name,
                "hash": file_hash,
                "chunks": len(chunks)
            })

            audit_event("DOCUMENT_INGESTED", {
                "file": filepath.name,
                "hash": file_hash,
                "chunks": len(chunks),
                "collection": collection_name,
            })

        except Exception as e:
            log.error(f"Erro processando {filepath.name}: {e}")
            stats["errors"] += 1

    # 7. Sumário
    log.info("═" * 60)
    log.info(f"✓ Ingestão concluída")
    log.info(f"  Arquivos processados: {stats['files']}")
    log.info(f"  Total de chunks:      {stats['chunks']}")
    log.info(f"  Erros:                {stats['errors']}")
    log.info(f"  Coleção:              {collection_name}")
    log.info(f"  Egress de dados:      0 bytes (sistema offline)")
    log.info("═" * 60)

    audit_event("INGEST_COMPLETED", {
        "collection": collection_name,
        "total_files": stats["files"],
        "total_chunks": stats["chunks"],
        "errors": stats["errors"],
    })

    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="AI-Hardened — Ingestão de documentos no vault LUKS"
    )
    parser.add_argument("--path", required=True, help="Caminho dos documentos a ingerir")
    parser.add_argument("--collection", required=True, help="Nome da coleção ChromaDB")
    parser.add_argument("--overwrite", action="store_true", help="Reprocessar coleção existente")
    args = parser.parse_args()

    result = ingest_documents(
        docs_path=Path(args.path),
        collection_name=args.collection,
        overwrite=args.overwrite
    )

    sys.exit(0 if result["errors"] == 0 else 1)
