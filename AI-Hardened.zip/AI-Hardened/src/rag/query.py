"""
AI-Hardened — RAG Query Engine
Busca semântica com reranking e citação precisa de fontes
SELOCK · selock.net
"""

import os
import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from dataclasses import dataclass, asdict

import chromadb
from chromadb.config import Settings
from langchain_community.embeddings import OllamaEmbeddings
import httpx

log = logging.getLogger("ai-hardened.query")

VAULT_PATH      = Path(os.getenv("VAULT_PATH", "/mnt/ai_vault"))
CHROMA_PATH     = VAULT_PATH / "chromadb"
OLLAMA_URL      = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
EMBED_MODEL     = os.getenv("EMBED_MODEL", "nomic-embed-text")
LLM_MODEL       = os.getenv("LLM_MODEL", "llama3:8b")
TOP_K           = int(os.getenv("RAG_TOP_K", "5"))
TEMPERATURE     = float(os.getenv("LLM_TEMPERATURE", "0.1"))


@dataclass
class Source:
    file: str
    file_hash: str
    chunk_index: int
    relevance: float
    excerpt: str


@dataclass
class RAGResult:
    question: str
    answer: str
    sources: list[Source]
    model: str
    collection: str
    processing_ms: int
    egress_bytes: int = 0
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self):
        d = asdict(self)
        d["sources"] = [asdict(s) for s in self.sources]
        return d


# Prompts especializados por domínio
DOMAIN_PROMPTS = {
    "juridico": """Você é um assistente jurídico especializado.
Responda EXCLUSIVAMENTE com base nos documentos fornecidos.
Ao citar informações, referencie explicitamente a fonte (ex: "Conforme o documento X...").
Se houver ambiguidade, aponte as diferentes interpretações possíveis.
JAMAIS invente jurisprudência, artigos de lei ou datas.""",

    "bancario": """Você é um assistente de compliance bancário.
Responda EXCLUSIVAMENTE com base nos documentos fornecidos.
Seja preciso com valores, datas e termos contratuais.
Destaque riscos ou inconsistências identificadas nos documentos.
JAMAIS extrapole além do que está documentado.""",

    "governamental": """Você é um assistente para análise de documentos governamentais.
Responda EXCLUSIVAMENTE com base nos documentos fornecidos.
Cite os documentos de origem com precisão.
Mantenha neutralidade analítica.
Aponte lacunas de informação quando relevante.""",

    "default": """Você é um assistente especializado em análise de documentos.
Responda EXCLUSIVAMENTE com base no contexto fornecido.
Cite as fontes ao usar informações específicas.
Se a resposta não estiver no contexto, informe claramente.""",
}


def _detect_domain(collection_name: str) -> str:
    """Detecta domínio a partir do nome da coleção."""
    name = collection_name.lower()
    for domain in ["juridico", "bancario", "governamental"]:
        if domain in name:
            return domain
    return "default"


def _build_context(docs: list[str], metadatas: list[dict], distances: list[float]) -> tuple[str, list[Source]]:
    """Monta contexto RAG com numeração de fontes."""
    parts = []
    sources = []

    for i, (doc, meta, dist) in enumerate(zip(docs, metadatas, distances)):
        relevance = round(1 - dist, 4)
        if relevance < 0.1:  # Filtrar chunks pouco relevantes
            continue

        source_name = meta.get("source_file", f"documento_{i+1}")
        chunk_idx   = meta.get("chunk_index", 0)
        file_hash   = meta.get("source_hash", "?")

        parts.append(f"[FONTE {i+1} — {source_name}, trecho {chunk_idx}]\n{doc}")

        sources.append(Source(
            file=source_name,
            file_hash=file_hash[:12],
            chunk_index=chunk_idx,
            relevance=relevance,
            excerpt=doc[:200] + "..." if len(doc) > 200 else doc,
        ))

    return "\n\n" + ("─" * 40) + "\n\n".join(parts), sources


async def query_rag(
    question: str,
    collection_name: str,
    model: str = LLM_MODEL,
    top_k: int = TOP_K,
    client: Optional[chromadb.PersistentClient] = None,
) -> RAGResult:
    """
    Pipeline RAG completo:
    1. Embed da query (local)
    2. Busca vetorial + filtragem por relevância
    3. Prompt especializado por domínio
    4. Geração LLM local
    5. Retorno estruturado com fontes
    """
    import time
    start = time.monotonic()

    # Inicializar clientes
    if client is None:
        client = chromadb.PersistentClient(
            path=str(CHROMA_PATH),
            settings=Settings(anonymized_telemetry=False)
        )

    embeddings = OllamaEmbeddings(base_url=OLLAMA_URL, model=EMBED_MODEL)

    # Embed da query
    query_vector = embeddings.embed_query(question)

    # Busca vetorial
    col     = client.get_or_create_collection(collection_name)
    results = col.query(
        query_embeddings=[query_vector],
        n_results=min(top_k, 10),
        include=["documents", "metadatas", "distances"]
    )

    docs      = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0]

    if not docs:
        return RAGResult(
            question=question,
            answer="Nenhum documento relevante encontrado na coleção. Verifique se os documentos foram ingeridos corretamente.",
            sources=[],
            model=model,
            collection=collection_name,
            processing_ms=0,
        )

    # Montar contexto e fontes
    context, sources = _build_context(docs, metadatas, distances)

    if not sources:
        return RAGResult(
            question=question,
            answer="Os documentos encontrados têm baixa relevância para esta pergunta.",
            sources=[],
            model=model,
            collection=collection_name,
            processing_ms=0,
        )

    # Prompt especializado por domínio
    domain        = _detect_domain(collection_name)
    system_prompt = DOMAIN_PROMPTS[domain]

    user_prompt = f"""DOCUMENTOS DE CONTEXTO:
{context}

{'─' * 40}

PERGUNTA: {question}

Responda com base nos documentos acima. Cite as fontes pelo número [FONTE N] quando usar informações específicas."""

    # Geração via Ollama (100% local)
    async with httpx.AsyncClient(timeout=180.0) as http:
        resp = await http.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_prompt},
                ],
                "stream": False,
                "options": {
                    "temperature": TEMPERATURE,
                    "num_predict": 2048,
                    "top_p": 0.9,
                }
            }
        )
        resp.raise_for_status()
        answer = resp.json()["message"]["content"]

    elapsed_ms = int((time.monotonic() - start) * 1000)

    return RAGResult(
        question=question,
        answer=answer,
        sources=sources,
        model=model,
        collection=collection_name,
        processing_ms=elapsed_ms,
        egress_bytes=0,  # Sempre zero — sistema offline
    )


async def list_collections(client: Optional[chromadb.PersistentClient] = None) -> list[dict]:
    """Lista coleções com estatísticas."""
    if client is None:
        client = chromadb.PersistentClient(
            path=str(CHROMA_PATH),
            settings=Settings(anonymized_telemetry=False)
        )

    result = []
    for col in client.list_collections():
        try:
            count = col.count()
            result.append({"name": col.name, "chunks": count})
        except Exception:
            result.append({"name": col.name, "chunks": -1})
    return result
