#!/usr/bin/env bash
# ============================================================
# AI-Hardened — LUKS Vault Setup
# SELOCK · selock.net
# ============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

VAULT_NAME="ai_vault"
VAULT_IMAGE="/var/lib/ai-hardened/vault.img"
VAULT_SIZE="20G"
VAULT_KEYFILE="/etc/ai-hardened/vault.key"
MOUNT_POINT="/mnt/ai_vault"

usage() {
  echo "Usage: $0 [--size 50G] [--keyfile /path/to/key] [--image /path/to/vault.img]"
  exit 1
}

log()  { echo -e "${CYAN}[AI-Hardened]${NC} $*"; }
ok()   { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
fail() { echo -e "${RED}[✗] FATAL:${NC} $*"; exit 1; }

# Parse args
while [[ $# -gt 0 ]]; do
  case $1 in
    --size)     VAULT_SIZE="$2"; shift 2 ;;
    --keyfile)  VAULT_KEYFILE="$2"; shift 2 ;;
    --image)    VAULT_IMAGE="$2"; shift 2 ;;
    *)          usage ;;
  esac
done

[[ $EUID -ne 0 ]] && fail "Este script requer privilégios root."

command -v cryptsetup >/dev/null 2>&1 || fail "cryptsetup não encontrado. Instale com: apt install cryptsetup"

log "=== AI-Hardened LUKS Vault Setup ==="
log "Tamanho do vault: ${VAULT_SIZE}"
log "Keyfile: ${VAULT_KEYFILE}"
log "Imagem: ${VAULT_IMAGE}"
echo ""

# 1. Criar diretório seguro para keyfile
log "Criando diretório para keyfile..."
mkdir -p "$(dirname "$VAULT_KEYFILE")"
chmod 700 "$(dirname "$VAULT_KEYFILE")"

# 2. Gerar keyfile com entropia de /dev/urandom
if [[ ! -f "$VAULT_KEYFILE" ]]; then
  log "Gerando keyfile de 4096 bits via /dev/urandom..."
  dd if=/dev/urandom bs=512 count=1 of="$VAULT_KEYFILE" status=none
  chmod 400 "$VAULT_KEYFILE"
  ok "Keyfile gerado: ${VAULT_KEYFILE}"
else
  warn "Keyfile já existe, reutilizando."
fi

# 3. Criar imagem do vault
log "Criando imagem de disco (${VAULT_SIZE})..."
mkdir -p "$(dirname "$VAULT_IMAGE")"

SIZE_BYTES=$(numfmt --from=iec "$VAULT_SIZE")
dd if=/dev/zero bs=1M count=$((SIZE_BYTES / 1024 / 1024)) of="$VAULT_IMAGE" status=progress
ok "Imagem criada: ${VAULT_IMAGE}"

# 4. Configurar LUKS com AES-256-XTS e SHA-512
log "Formatando volume LUKS2 (AES-256-XTS / SHA-512)..."
cryptsetup luksFormat \
  --type luks2 \
  --cipher aes-xts-plain64 \
  --key-size 512 \
  --hash sha512 \
  --pbkdf argon2id \
  --pbkdf-memory 65536 \
  --pbkdf-parallel 4 \
  --iter-time 5000 \
  --key-file "$VAULT_KEYFILE" \
  --batch-mode \
  "$VAULT_IMAGE"
ok "Volume LUKS2 formatado com AES-256-XTS + Argon2id"

# 5. Abrir e formatar com ext4
log "Abrindo vault para formatação inicial..."
cryptsetup open --key-file "$VAULT_KEYFILE" "$VAULT_IMAGE" "$VAULT_NAME"

log "Formatando sistema de arquivos ext4..."
mkfs.ext4 -L "ai_hardened_vault" "/dev/mapper/${VAULT_NAME}" >/dev/null 2>&1
ok "Sistema de arquivos ext4 criado"

# 6. Montar e criar estrutura de diretórios
log "Montando vault e criando estrutura..."
mkdir -p "$MOUNT_POINT"
mount "/dev/mapper/${VAULT_NAME}" "$MOUNT_POINT"

mkdir -p "${MOUNT_POINT}/"{docs,embeddings,chromadb,audit_logs,models_cache}
chmod 700 "${MOUNT_POINT}/audit_logs"
ok "Estrutura de diretórios criada em ${MOUNT_POINT}"

# 7. Registrar metadata do vault
cat > "${MOUNT_POINT}/.vault_meta" << EOF
{
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "cipher": "aes-xts-plain64",
  "key_size": 512,
  "hash": "sha512",
  "pbkdf": "argon2id",
  "luks_version": 2,
  "project": "AI-Hardened",
  "maintainer": "SELOCK (selock.net)"
}
EOF

# 8. Verificar isolamento LUKS
log "Verificando integridade do header LUKS..."
cryptsetup luksDump "$VAULT_IMAGE" | grep -E "(Version|Cipher|Hash|MK bits)" | while read line; do
  echo -e "  ${CYAN}${line}${NC}"
done

# 9. Desmontagem segura
umount "$MOUNT_POINT"
cryptsetup close "$VAULT_NAME"
ok "Vault selado com sucesso"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         VAULT CONFIGURADO COM SUCESSO                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
log "Para montar: ./scripts/mount_vault.sh"
log "Para selar:  ./scripts/unmount_vault.sh"
echo ""
warn "GUARDE O KEYFILE EM LOCAL SEGURO: ${VAULT_KEYFILE}"
warn "Sem o keyfile, os dados são IRRECUPERÁVEIS."
