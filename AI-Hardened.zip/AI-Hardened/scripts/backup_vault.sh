#!/usr/bin/env bash
# ============================================================
# AI-Hardened — Backup Seguro do Vault LUKS
# Backup da imagem criptografada com verificação de integridade
# SELOCK · selock.net
# ============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
BOLD='\033[1m'

VAULT_IMAGE="${VAULT_IMAGE:-/var/lib/ai-hardened/vault.img}"
BACKUP_DIR="${1:-/mnt/backup/ai-hardened}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/vault_backup_${TIMESTAMP}.img.gz"
CHECKSUM_FILE="${BACKUP_DIR}/vault_backup_${TIMESTAMP}.sha256"

log()  { echo -e "${CYAN}[Backup]${NC} $*"; }
ok()   { echo -e "${GREEN}[✓]${NC} $*"; }
fail() { echo -e "${RED}[✗]${NC} $*"; exit 1; }

[[ $EUID -ne 0 ]] && fail "Requer root."
[[ ! -f "$VAULT_IMAGE" ]] && fail "Vault não encontrado: ${VAULT_IMAGE}"

log "=== AI-Hardened Backup Seguro ==="
log "Origem:  ${VAULT_IMAGE}"
log "Destino: ${BACKUP_FILE}"
echo ""

# 1. Verificar que o vault está SELADO (não montado)
if cryptsetup status ai_vault &>/dev/null; then
  echo -e "${YELLOW}[!]${NC} Vault está montado. Recomendado fazer backup com vault selado."
  read -p "    Continuar mesmo assim? [s/N] " -n 1 -r
  echo
  [[ ! $REPLY =~ ^[Ss]$ ]] && { log "Backup cancelado."; exit 0; }
fi

# 2. Criar diretório de backup
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

# 3. Calcular hash do original ANTES
log "Calculando hash SHA-256 do vault original..."
ORIGINAL_HASH=$(sha256sum "$VAULT_IMAGE" | awk '{print $1}')
log "Hash original: ${ORIGINAL_HASH}"

# 4. Fazer backup comprimido
log "Copiando e comprimindo vault (pode demorar)..."
SIZE=$(du -h "$VAULT_IMAGE" | awk '{print $1}')
log "Tamanho original: ${SIZE}"

pv "$VAULT_IMAGE" 2>/dev/null | gzip -9 > "$BACKUP_FILE" || \
  gzip -9 -c "$VAULT_IMAGE" > "$BACKUP_FILE"

ok "Backup criado: ${BACKUP_FILE}"

# 5. Verificar integridade do backup
log "Verificando integridade do backup..."
BACKUP_DECOMP_HASH=$(zcat "$BACKUP_FILE" | sha256sum | awk '{print $1}')

if [[ "$ORIGINAL_HASH" == "$BACKUP_DECOMP_HASH" ]]; then
  ok "Integridade verificada — hashes idênticos"
else
  fail "ERRO: Hash do backup (${BACKUP_DECOMP_HASH}) difere do original (${ORIGINAL_HASH})"
fi

# 6. Salvar arquivo de checksum
cat > "$CHECKSUM_FILE" << EOF
{
  "timestamp":     "${TIMESTAMP}",
  "vault_image":   "${VAULT_IMAGE}",
  "backup_file":   "${BACKUP_FILE}",
  "original_hash": "${ORIGINAL_HASH}",
  "backup_hash":   "${BACKUP_DECOMP_HASH}",
  "vault_sealed":  "$(cryptsetup status ai_vault &>/dev/null && echo false || echo true)",
  "operator":      "$(whoami)",
  "hostname":      "$(hostname)"
}
EOF
chmod 400 "$CHECKSUM_FILE"
ok "Checksum salvo: ${CHECKSUM_FILE}"

# 7. Limpar backups antigos (manter 7 últimos)
log "Gerenciando retenção de backups (últimos 7)..."
ls -t "${BACKUP_DIR}"/vault_backup_*.img.gz 2>/dev/null | tail -n +8 | while read old; do
  rm -f "$old" "${old%.img.gz}.sha256"
  log "  Removido: $(basename $old)"
done

# 8. Sumário
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | awk '{print $1}')
echo ""
echo -e "${BOLD}${GREEN}═══════════════════════════════════════${NC}"
echo -e "  BACKUP CONCLUÍDO COM SUCESSO"
echo -e "${BOLD}${GREEN}═══════════════════════════════════════${NC}"
log "Arquivo: $(basename $BACKUP_FILE)"
log "Tamanho: ${BACKUP_SIZE} (comprimido de ${SIZE})"
log "Hash:    ${ORIGINAL_HASH}"
echo ""
echo -e "${YELLOW}IMPORTANTE: Armazene o backup em local FISICAMENTE separado.${NC}"
echo -e "${YELLOW}O arquivo .img.gz continua criptografado (LUKS).${NC}"
echo -e "${YELLOW}Sem o keyfile original, é irrecuperável.${NC}"
