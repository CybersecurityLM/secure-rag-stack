#!/usr/bin/env bash
# mount_vault.sh — Monta o vault LUKS e aplica regras de firewall
set -euo pipefail
[[ $EUID -ne 0 ]] && { echo "Requer root."; exit 1; }

VAULT_NAME="ai_vault"
VAULT_IMAGE="${1:-/var/lib/ai-hardened/vault.img}"
VAULT_KEYFILE="/etc/ai-hardened/vault.key"
MOUNT_POINT="/mnt/ai_vault"

echo "[AI-Hardened] Montando vault LUKS..."
cryptsetup open --key-file "$VAULT_KEYFILE" "$VAULT_IMAGE" "$VAULT_NAME"
mkdir -p "$MOUNT_POINT"
mount "/dev/mapper/${VAULT_NAME}" "$MOUNT_POINT"

echo "[AI-Hardened] Aplicando regras de isolamento de rede..."
iptables -P OUTPUT DROP
iptables -F OUTPUT
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A OUTPUT -d 172.28.0.0/16 -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

echo "[✓] Vault montado em ${MOUNT_POINT}"
echo "[✓] Isolamento de rede aplicado — egress externo bloqueado"
