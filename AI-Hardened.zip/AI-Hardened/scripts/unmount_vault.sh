#!/usr/bin/env bash
# unmount_vault.sh — Desmonta e sela o vault LUKS com segurança
set -euo pipefail
[[ $EUID -ne 0 ]] && { echo "Requer root."; exit 1; }

VAULT_NAME="ai_vault"
MOUNT_POINT="/mnt/ai_vault"

echo "[AI-Hardened] Parando serviços..."
docker-compose down 2>/dev/null || true

echo "[AI-Hardened] Sincronizando dados..."
sync

echo "[AI-Hardened] Desmontando vault..."
umount "$MOUNT_POINT" 2>/dev/null || true
cryptsetup close "$VAULT_NAME" 2>/dev/null || true

echo "[✓] Vault SELADO — dados criptografados e inacessíveis"
