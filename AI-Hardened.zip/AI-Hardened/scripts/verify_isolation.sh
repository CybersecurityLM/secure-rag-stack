#!/usr/bin/env bash
# ============================================================
# AI-Hardened — Network Isolation Verifier
# Audita que ZERO dados saem para a internet
# SELOCK · selock.net
# ============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'
BOLD='\033[1m'; NC='\033[0m'

PASS=0; FAIL=0; WARN=0

ok()   { echo -e "  ${GREEN}[✓]${NC} $*"; ((PASS++)); }
fail() { echo -e "  ${RED}[✗]${NC} $*"; ((FAIL++)); }
warn() { echo -e "  ${YELLOW}[!]${NC} $*"; ((WARN++)); }
section() { echo -e "\n${BOLD}${CYAN}── $* ──${NC}"; }

echo -e "${BOLD}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║         AI-Hardened · Network Isolation Audit             ║"
echo "║                     SELOCK · selock.net                   ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── 1. VERIFICAR BIND DO OLLAMA ──────────────────────────────
section "Ollama Bind Address"

if ss -tlnp 2>/dev/null | grep -q "127.0.0.1:11434"; then
  ok "Ollama escutando SOMENTE em 127.0.0.1:11434"
elif ss -tlnp 2>/dev/null | grep -q "0.0.0.0:11434"; then
  fail "Ollama exposto em 0.0.0.0:11434 — PERIGO: acessível na rede local"
else
  warn "Ollama não encontrado em execução"
fi

# ── 2. VERIFICAR BIND DO CHROMADB ───────────────────────────
section "ChromaDB Bind Address"

if ss -tlnp 2>/dev/null | grep -q "127.0.0.1:8000"; then
  ok "ChromaDB escutando SOMENTE em 127.0.0.1:8000"
elif ss -tlnp 2>/dev/null | grep -q "0.0.0.0:8000"; then
  fail "ChromaDB exposto em 0.0.0.0:8000"
else
  warn "ChromaDB não encontrado em execução"
fi

# ── 3. VERIFICAR REGRAS IPTABLES ────────────────────────────
section "IPTables Outbound Policy"

if command -v iptables &>/dev/null; then
  OUTPUT_POLICY=$(iptables -L OUTPUT --line-numbers -n 2>/dev/null | head -1 | awk '{print $NF}')
  if [[ "$OUTPUT_POLICY" == "DROP" ]]; then
    ok "Política OUTPUT padrão: DROP"
  else
    fail "Política OUTPUT padrão: ${OUTPUT_POLICY} (esperado: DROP)"
  fi

  LOOPBACK_RULE=$(iptables -L OUTPUT -n 2>/dev/null | grep -c "lo.*ACCEPT" || true)
  if [[ "$LOOPBACK_RULE" -gt 0 ]]; then
    ok "Loopback (lo) permitido para operação local"
  else
    warn "Regra de loopback não encontrada — pode impedir funcionamento"
  fi
else
  warn "iptables não disponível — verificar nftables ou firewalld"
fi

# ── 4. TESTAR CONECTIVIDADE EXTERNA ─────────────────────────
section "External Connectivity Tests"

EXTERNAL_HOSTS=(
  "8.8.8.8"
  "1.1.1.1"
  "api.openai.com"
  "huggingface.co"
  "ollama.com"
)

for host in "${EXTERNAL_HOSTS[@]}"; do
  if timeout 3 bash -c "echo > /dev/tcp/${host}/443" 2>/dev/null; then
    fail "Conexão POSSÍVEL com ${host}:443 — ISOLAR REDE"
  elif timeout 3 ping -c 1 "$host" &>/dev/null; then
    fail "Ping bem-sucedido para ${host} — ISOLAR REDE"
  else
    ok "Bloqueado: ${host}"
  fi
done

# ── 5. VERIFICAR DNS EXTERNO ────────────────────────────────
section "DNS Resolver Check"

RESOLV_CONF=$(cat /etc/resolv.conf 2>/dev/null || echo "")
if echo "$RESOLV_CONF" | grep -qE "^nameserver (8\.8\.|1\.1\.|208\.67\.)"; then
  fail "DNS externo configurado em /etc/resolv.conf — pode vazar queries"
elif echo "$RESOLV_CONF" | grep -qE "^nameserver 127\."; then
  ok "DNS apontando para resolver local (127.x.x.x)"
else
  warn "Configuração de DNS incomum — revisar /etc/resolv.conf"
fi

# ── 6. VERIFICAR PROCESSOS COM CONEXÕES ATIVAS ──────────────
section "Active External Connections"

EXT_CONNS=$(ss -tnp 2>/dev/null | grep -v "127\." | grep -v "::1" | grep ESTAB | wc -l)
if [[ "$EXT_CONNS" -eq 0 ]]; then
  ok "Nenhuma conexão TCP externa estabelecida"
else
  fail "${EXT_CONNS} conexão(ões) externa(s) ativa(s):"
  ss -tnp 2>/dev/null | grep -v "127\." | grep -v "::1" | grep ESTAB | while read line; do
    echo -e "     ${RED}${line}${NC}"
  done
fi

# ── 7. VERIFICAR VAULT LUKS ─────────────────────────────────
section "LUKS Vault Status"

if cryptsetup status ai_vault &>/dev/null; then
  CIPHER=$(cryptsetup status ai_vault 2>/dev/null | grep cipher | awk '{print $2}')
  ok "Vault LUKS montado — cipher: ${CIPHER}"
elif [[ -f /var/lib/ai-hardened/vault.img ]]; then
  ok "Vault selado (não montado) — estado seguro"
else
  warn "Vault LUKS não configurado — executar setup_luks_vault.sh"
fi

# ── SUMÁRIO ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}═══════════════════════════════════════${NC}"
echo -e "  RESULTADO DA AUDITORIA"
echo -e "${BOLD}═══════════════════════════════════════${NC}"
echo -e "  ${GREEN}Passou:   ${PASS}${NC}"
echo -e "  ${YELLOW}Avisos:   ${WARN}${NC}"
echo -e "  ${RED}Falhou:   ${FAIL}${NC}"
echo ""

if [[ "$FAIL" -gt 0 ]]; then
  echo -e "${RED}${BOLD}  ⚠ ISOLAMENTO COMPROMETIDO — NÃO PROCESSAR DADOS SENSÍVEIS${NC}"
  exit 1
elif [[ "$WARN" -gt 0 ]]; then
  echo -e "${YELLOW}${BOLD}  ⚠ Avisos presentes — revisar antes de produção${NC}"
  exit 0
else
  echo -e "${GREEN}${BOLD}  ✓ SISTEMA COMPLETAMENTE ISOLADO — SEGURO PARA OPERAÇÃO${NC}"
  exit 0
fi
