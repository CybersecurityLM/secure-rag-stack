#!/usr/bin/env bash
# ============================================================
# AI-Hardened — Setup Completo (One-shot)
# Configura tudo: LUKS, Ollama, Docker, Firewall
# Execute UMA VEZ em um servidor Linux fresco
# SELOCK · selock.net
# ============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()     { echo -e "${CYAN}[Setup]${NC} $*"; }
ok()      { echo -e "${GREEN}[✓]${NC} $*"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*"; }
fail()    { echo -e "${RED}[✗] FATAL:${NC} $*"; exit 1; }
section() { echo -e "\n${BOLD}${CYAN}━━━ $* ━━━${NC}"; }

[[ $EUID -ne 0 ]] && fail "Execute como root: sudo $0"

# Verificar OS
. /etc/os-release 2>/dev/null || true
if [[ "${ID:-}" != "ubuntu" && "${ID:-}" != "debian" ]]; then
  warn "OS não testado oficialmente: ${PRETTY_NAME:-desconhecido}"
  warn "Prosseguindo — pode requerer ajustes manuais."
fi

clear
echo -e "${BOLD}"
cat << 'BANNER'
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║          AI-Hardened — Setup Automatizado                    ║
║          IA Privada com Vault Criptografado                  ║
║          SELOCK · selock.net                                 ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

echo -e "${YELLOW}Este script irá:${NC}"
echo "  1. Instalar dependências (Docker, cryptsetup, etc.)"
echo "  2. Criar vault LUKS de 20GB"
echo "  3. Instalar e configurar Ollama"
echo "  4. Baixar modelos de IA localmente"
echo "  5. Configurar firewall de isolamento"
echo "  6. Subir stack Docker"
echo ""
read -p "Continuar? [s/N] " -n 1 -r && echo
[[ ! $REPLY =~ ^[Ss]$ ]] && { log "Cancelado."; exit 0; }

# ── 1. DEPENDÊNCIAS ──────────────────────────────────────────
section "Instalando Dependências"

apt update -qq
apt install -y -qq \
  docker.io docker-compose-v2 \
  cryptsetup \
  python3-pip python3-venv \
  curl wget git \
  iptables-persistent \
  pv pigz \
  2>/dev/null

ok "Dependências instaladas"

# Docker daemon
systemctl enable --now docker
ok "Docker iniciado"

# ── 2. OLLAMA ────────────────────────────────────────────────
section "Instalando Ollama"

if ! command -v ollama &>/dev/null; then
  log "Baixando Ollama..."
  curl -fsSL https://ollama.com/install.sh | sh
  ok "Ollama instalado"
else
  ok "Ollama já instalado: $(ollama --version 2>/dev/null || echo 'versão desconhecida')"
fi

# Configurar para bind somente localhost
mkdir -p /etc/systemd/system/ollama.service.d/
cat > /etc/systemd/system/ollama.service.d/hardened.conf << 'EOF'
[Service]
Environment="OLLAMA_HOST=127.0.0.1"
Environment="OLLAMA_ORIGINS=http://127.0.0.1,http://172.28.0.0/16"
EOF

systemctl daemon-reload
systemctl enable --now ollama
sleep 3
ok "Ollama configurado para bind localhost"

# ── 3. VAULT LUKS ─────────────────────────────────────────────
section "Configurando Vault LUKS"

if [[ ! -f /var/lib/ai-hardened/vault.img ]]; then
  bash ./scripts/setup_luks_vault.sh --size 20G
else
  warn "Vault já existe — pulando criação"
fi

bash ./scripts/mount_vault.sh
ok "Vault montado em /mnt/ai_vault"

# ── 4. MODELOS DE IA ─────────────────────────────────────────
section "Baixando Modelos de IA"

log "Baixando nomic-embed-text (embeddings)..."
ollama pull nomic-embed-text
ok "nomic-embed-text instalado"

log "Baixando llama3:8b (LLM principal — ~4.7GB)..."
ollama pull llama3:8b
ok "llama3:8b instalado"

log "Baixando phi3:mini (LLM alternativo rápido)..."
ollama pull phi3:mini
ok "phi3:mini instalado"

# ── 5. AMBIENTE PYTHON ────────────────────────────────────────
section "Configurando Ambiente Python"

python3 -m venv .venv
source .venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
ok "Dependências Python instaladas"

# ── 6. ARQUIVO .env ───────────────────────────────────────────
section "Configurando Variáveis de Ambiente"

if [[ ! -f .env ]]; then
  cp configs/env.example .env
  # Gerar JWT secret aleatório
  JWT_SECRET=$(openssl rand -hex 32)
  sed -i "s/TROQUE_ISSO_POR_UM_SEGREDO_FORTE/${JWT_SECRET}/" .env
  chmod 600 .env
  ok ".env criado com JWT secret aleatório"
else
  warn ".env já existe — mantendo configurações atuais"
fi

# ── 7. FIREWALL ──────────────────────────────────────────────
section "Configurando Firewall de Isolamento"

# Aplicar regras
iptables -P OUTPUT DROP
iptables -F OUTPUT
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A OUTPUT -d 172.28.0.0/16 -j ACCEPT
iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# Persistir regras
netfilter-persistent save 2>/dev/null || iptables-save > /etc/iptables/rules.v4

ok "Firewall configurado — OUTPUT padrão: DROP"

# ── 8. DOCKER STACK ──────────────────────────────────────────
section "Subindo Stack Docker"

docker compose up -d --build
log "Aguardando serviços iniciarem..."
sleep 10

# Verificar saúde
for service in ollama chromadb api; do
  if docker compose ps "$service" 2>/dev/null | grep -q "healthy\|running"; then
    ok "Serviço ${service}: OK"
  else
    warn "Serviço ${service}: verificar logs com 'docker compose logs ${service}'"
  fi
done

# ── 9. VERIFICAÇÃO FINAL ─────────────────────────────────────
section "Verificação de Isolamento"

bash ./scripts/verify_isolation.sh

# ── SUMÁRIO ──────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}"
cat << 'SUCCESS'
╔══════════════════════════════════════════════════════════════╗
║           SETUP CONCLUÍDO COM SUCESSO                        ║
╚══════════════════════════════════════════════════════════════╝
SUCCESS
echo -e "${NC}"

echo -e "  ${CYAN}Interfaces disponíveis:${NC}"
echo -e "  • Interface Web:  http://localhost:3000"
echo -e "  • API REST:       http://localhost:8080"
echo -e "  • API Docs:       http://localhost:8080/docs"
echo -e "  • Ollama:         http://localhost:11434"
echo ""
echo -e "  ${CYAN}Próximos passos:${NC}"
echo -e "  1. Copiar documentos para /mnt/ai_vault/docs/"
echo -e "  2. Ingerir: python3 src/rag/ingest.py --path /mnt/ai_vault/docs/ --collection juridico"
echo -e "  3. Acessar: http://localhost:3000"
echo ""
echo -e "  ${YELLOW}Keyfile do vault: /etc/ai-hardened/vault.key${NC}"
echo -e "  ${YELLOW}FAÇA BACKUP DESTE ARQUIVO EM LOCAL SEGURO${NC}"
